<?php
$dbServername = "localhost";
$dbUsername = "root";
$dbPassword = "";
$dbName = "loginsystem";

$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

if ($conn)
{
	echo '';
}
else
{
	die("Error!".mysqli_connect_error());
}
?>