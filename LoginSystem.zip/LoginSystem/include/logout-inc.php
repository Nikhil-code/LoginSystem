<?php
	session_start();
	session_unset(); //it takes all the session variables that we created when we loged in and it delete all the values inside those session variables
	session_destroy();
	header("Location: ../index.php");
?>