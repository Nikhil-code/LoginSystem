<?php
	if (isset($_POST['signup-submit'])) {
		require 'dbh-inc.php';
		$username = mysqli_real_escape_string($conn, $_POST['uid']);
		$email = mysqli_real_escape_string($conn, $_POST['mail']);
		$password = mysqli_real_escape_string($conn, $_POST['pwd']);
		$passwordRepeat = mysqli_real_escape_string($conn, $_POST['pwd-repeat']);

		// Error Handler

		// Check if all the inputs field are empty
		if (empty($username) || empty($email) || empty($password) || empty($passwordRepeat)) {
			header("Location: ../signup.php?error=emptyfields");
			exit();
		}
		// Chech if email and username are invalid
		elseif (!filter_var($email, FILTER_VALIDATE_EMAIL) && !preg_match("/^[a-zA-Z0-9]*$/", $username)) {
			header("Location: ../signup.php?error=invalidmailuid");
			exit();
		}
		// Chech if only email id invalid
		elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
			header("Location: ../signup.php?error=invalidmail");
			exit();
		}
		// Chech if only username id invalid
		elseif (!preg_match("/^[a-zA-Z0-9]*$/", $username)) {
			header("Location: ../signup.php?error=invalidusername");
			exit();
		}
		// Check if password and re-password are same
		elseif ($password !== $passwordRepeat) {
			header("Location: ../signup.php?error=passwordcheck");
		}
		else {
			// Checking if the given username exist in database
			$sql = "SELECT uidUsers FROM users1 WHERE uidUsers=?";
			$stmt = mysqli_stmt_init($conn);
			if (!mysqli_stmt_prepare($stmt, $sql)) {
				header("Location: ../signup.php?error=sqlerror");
				exit();
			}
			else {
				mysqli_stmt_bind_param($stmt, "s", $username);
				mysqli_stmt_execute($stmt);
				mysqli_stmt_store_result($stmt);
				$resultCheck = mysqli_stmt_num_rows($stmt);
				if ($resultCheck > 0) {
					header("Location: ../signup.php?error=usertaken");
					exit();
				}
				else {
					$sql = "INSERT INTO users1 (uidUsers, emailUsers, pwdUsers) VALUES (?, ?, ?)";
					$stmt = mysqli_stmt_init($conn);
					if (!mysqli_stmt_prepare($stmt, $sql)) {
						header("Location: ../signup.php?error=sqlerror");
						exit();
					}
					else {
						$hashedPwd = password_hash($password, PASSWORD_DEFAULT);
						mysqli_stmt_bind_param($stmt, "sss", $username, $email, $hashedPwd);
						mysqli_stmt_execute($stmt);
						mysqli_stmt_store_result($stmt);
						header("Location: ../signup.php?signup=success");
						exit();
					}
				}
			}

		}
		mysqli_stmt_close($stmt);
		mysqli_close($conn);
	}
	else {
		header("Location: ../signup.php");
		exit();
	}
?>